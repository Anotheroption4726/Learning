<?php

require 'db_connect.php';

if(isset($_POST['addUser'])){

  $db = db_connect();

  /*
  $req = $db->prepare('INSERT INTO users_2 (email, password) VALUES (:monEmail, :monMdp)');
  $req->execute(array(
    'monEmail' => $_POST['email'],
    'monMdp'  => $_POST['password']
  ));
  */

  $reqDeFou = $db->prepare('SELECT COUNT(id) as nombre FROM users_2');
  $reqDeFou->execute(array());

  $dataGenial = $reqDeFou->fetch();

  echo $dataGenial['nombre'];

  if($dataGenial['nombre'] < 10){
    // Insert ....
  }else {
    echo "Pas possible";
  }
}
